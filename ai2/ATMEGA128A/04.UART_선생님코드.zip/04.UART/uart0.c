﻿/*
 * uart0.c
 *
 * Created: 2026-06-16 오전 9:57:59
 *  Author: user
 */ 
#include "uart0.h"

void init_uart0(void);
void UART0_transmit(uint8_t data);

/*
1. 전송속도 : 9600bps 
2. start/stop 설정
3. RX(수신) : interrupt 로 설정 
*/
void init_uart0(void)
{
	// 1. 전송속도 : 9600bps 
	UBRR0H = 0x00;
	UBRR0L = 207;   //9600BPS 표8-9
	UCSR0A |= 1 << U2X0;  // 2배속 설정 (sampling 8)
	// UART0 를 송신.수신이 다 가능하고 RX INT가 가능 하도록 설정 한다.
	UCSR0B |= 1 << RXEN0 | 1 << TXEN0 | 1 << RXCIE0;   
}

// UART0 로 1byte를 전송 하는 함수 
void UART0_transmit(uint8_t data)
{
	while ( !(UCSR0A & 1 << UDRE0))   // data가 송신중이면 송신이 끝날때 까지 기다림
		;     // No operation
	UDR0 = data;   // HW 전송 register에 data를 송신 한다. 
}